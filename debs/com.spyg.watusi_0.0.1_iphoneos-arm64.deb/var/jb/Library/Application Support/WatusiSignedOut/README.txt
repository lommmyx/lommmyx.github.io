PRIVATE VALIDATION BUILD - not an all-features release.
ALWAYS-ON BUILD: ignores startup/disable markers and automatic watchdog stops.
Recovery: remove com.spyg.watusi in the package manager, then restart WhatsApp.
Status: WhatsApp Library/Caches/WatusiSignedOut.status.json.
No original Watusi files, account state, or preferences are overwritten.
